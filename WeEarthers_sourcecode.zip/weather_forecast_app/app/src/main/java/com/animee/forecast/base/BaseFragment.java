package com.animee.forecast.base;

import android.support.v4.app.Fragment;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

/* use xutils to request the network
*  1.module declaration
*  2.network request
* */
public class BaseFragment extends Fragment implements Callback.CommonCallback<String>{

    public void loadData(String path){
        RequestParams params = new RequestParams(path);
        x.http().get(params,this);
    }
//    API to callback after getting access to data successfully
    @Override
    public void onSuccess(String result) {

    }
//  API to callback after getting access to data unsuccessfully
    @Override
    public void onError(Throwable ex, boolean isOnCallback) {

    }
//  When request cancelled
    @Override
    public void onCancelled(CancelledException cex) {

    }
//  When request finished
    @Override
    public void onFinished() {

    }
}
